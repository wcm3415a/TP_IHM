@echo off
chcp 65001 >nul
TITLE Lanceur Global - Moteur de Fusion Multimodale

echo ========================================================
echo    DEMARRAGE DE L'ARCHITECTURE MULTIMODALE - IVY
echo ========================================================
echo.

:: 1. Verification ou Creation automatique du .venv
if exist "%~dp0.venv\Scripts\python.exe" goto VENV_OK

echo [INFO] Premier lancement detecte : creation de l'environnement Python 3.12...
py -3.12 -m venv "%~dp0.venv"
if errorlevel 1 (
    echo [ERREUR] Impossible de creer le venv avec Python 3.12.
    echo Verifiez que Python 3.12 est bien installe : winget install Python.Python.3.12
    pause
    exit /b
)

echo [INFO] Installation des dependances MediaPipe et Ivy...
if exist "%~dp0requirement.txt" "%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirement.txt"
if exist "%~dp0requirements.txt" "%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
echo [OK] Environnement Python pret !
echo.

:VENV_OK

:: 2. Recherche automatique de Processing.exe
set "PROCESSING_BIN=%~dp0Processing\Processing.exe"
if exist "%PROCESSING_BIN%" goto LAUNCH_ALL

set "PROCESSING_BIN=C:\Program Files\Processing\Processing.exe"
if exist "%PROCESSING_BIN%" goto LAUNCH_ALL

set "PROCESSING_BIN=%LOCALAPPDATA%\Programs\Processing\Processing.exe"
if exist "%PROCESSING_BIN%" goto LAUNCH_ALL

set "PROCESSING_BIN=Processing.exe"

:LAUNCH_ALL

:: 3. Lancement de la reconnaissance vocale SRA5
echo [1/5] Demarrage de SRA5...
start "SRA5" /D "%~dp0sra5\sra5" "%~dp0sra5\sra5\sra5.exe"
timeout /t 1 /nobreak >nul

:: 4. Lancement du script Camera
echo [2/5] Demarrage de la camera MediaPipe...
start "CameraGesture" "%~dp0.venv\Scripts\python.exe" "%~dp0camera_gesture.py"
timeout /t 1 /nobreak >nul

:: 5. Lancement de OneDollarIvy
echo [3/5] Ouverture de OneDollarIvy...
start "" "%PROCESSING_BIN%" "%~dp0OneDollarIvy-main\OneDollarIvy-main\OneDollarIvy.pde"
timeout /t 1 /nobreak >nul

:: 6. Lancement de la Palette
echo [4/5] Ouverture de la Palette...
start "" "%PROCESSING_BIN%" "%~dp0Palette\Palette\Palette.pde"
timeout /t 1 /nobreak >nul

:: 7. Lancement de Fusion
echo [5/5] Ouverture du Dashboard Fusion...
start "" "%PROCESSING_BIN%" "%~dp0fusion\fusion.pde"

echo.
echo ========================================================
echo    TOUS LES SCRIPTS SONT LANCES !
echo    Appuyez sur Play ou Ctrl+R dans chaque fenetre Processing
echo ========================================================
pause
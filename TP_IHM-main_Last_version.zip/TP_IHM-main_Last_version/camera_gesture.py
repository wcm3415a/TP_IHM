import socket
import time
import cv2
from ivy.std_api import IvyInit, IvySendMsg, IvyStart, IvyStop
import mediapipe as mp

# =========================================================
# 1. CONNEXION AU BUS IVY ET AU FLUX VIDÉO UDP
# =========================================================
IvyInit(
    "CameraGesture",
    "CameraGesture is ready",
    0,
    lambda *a: None,
    lambda *a: None,
)
IvyStart("127.255.255.255:2010")

udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
UDP_IP = "127.0.0.1"
UDP_PORT = 5005

# =========================================================
# 2. INITIALISATION MEDIAPIPE (CORRIGÉE)
# =========================================================
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7,
)

FORMES_PAR_DOIGTS = {
    1: ("CARRE", "carre"),
    2: ("CERCLE", "cercle"),
    3: ("TRIANGLE", "triangle"),
    4: ("LOSANGE", "losange"),
}

DUREE_MAINTIEN = 1.0
COOLDOWN = 1.5

geste_actuel = 0
debut_maintien = 0
dernier_envoi = 0
texte_confirmation = ""

cap = cv2.VideoCapture(0)


def compter_doigts(hand_landmarks):
  tips = [8, 12, 16, 20]
  pips = [6, 10, 14, 18]
  count = 0
  for tip, pip in zip(tips, pips):
    if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[pip].y:
      count += 1
  return count


print(">>> Caméra démarrée ! Transmission vers Fusion sur le port UDP 5005...")

try:
  while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
      break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(rgb_frame)

    nb_doigts = 0

    if results.multi_hand_landmarks:
      for hand_landmarks in results.multi_hand_landmarks:
        mp_drawing.draw_landmarks(
            frame,
            hand_landmarks,
            mp_hands.HAND_CONNECTIONS,
            mp_drawing.DrawingSpec(
                color=(0, 255, 255), thickness=2, circle_radius=4
            ),
            mp_drawing.DrawingSpec(color=(255, 180, 0), thickness=2),
        )
        nb_doigts = compter_doigts(hand_landmarks)

    maintenant = time.time()

    if nb_doigts in FORMES_PAR_DOIGTS and (
        maintenant - dernier_envoi > COOLDOWN
    ):
      if nb_doigts != geste_actuel:
        geste_actuel = nb_doigts
        debut_maintien = maintenant
      else:
        temps_tenu = maintenant - debut_maintien
        ratio = min(1.0, temps_tenu / DUREE_MAINTIEN)
        nom_affiche, nom_ivy = FORMES_PAR_DOIGTS[nb_doigts]

        cv2.rectangle(frame, (0, 0), (w, 55), (35, 40, 50), -1)
        cv2.putText(
            frame,
            f"{nb_doigts} DOIGT(S) : {nom_affiche}",
            (15, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.0,
            (66, 165, 245),
            2,
        )

        cv2.rectangle(frame, (20, h - 30), (w - 20, h - 12), (50, 50, 50), -1)
        cv2.rectangle(
            frame,
            (20, h - 30),
            (int(20 + (w - 40) * ratio), h - 12),
            (76, 175, 80),
            -1,
        )

        if temps_tenu >= DUREE_MAINTIEN:
          msg = f"OneDollarIvy Template={nom_ivy} Confidence=0.98"
          IvySendMsg(msg)
          print(f">>> GESTE CAMÉRA ENVOYÉ SUR IVY : {msg}")
          dernier_envoi = maintenant
          texte_confirmation = f"VALIDE : {nom_affiche} !"
          geste_actuel = 0
    else:
      geste_actuel = 0
      if maintenant - dernier_envoi <= COOLDOWN and texte_confirmation:
        cv2.rectangle(frame, (0, 0), (w, 55), (40, 160, 60), -1)
        cv2.putText(
            frame,
            texte_confirmation,
            (15, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.0,
            (255, 255, 255),
            2,
        )
      else:
        cv2.rectangle(frame, (0, 0), (w, 55), (35, 40, 50), -1)
        cv2.putText(
            frame,
            "Montrez 1, 2, 3 ou 4 doigts",
            (15, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (200, 200, 200),
            2,
        )

    small_frame = cv2.resize(frame, (320, 180))
    ok, buffer = cv2.imencode(
        ".jpg", small_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 75]
    )
    if ok:
      udp_sock.sendto(buffer.tobytes(), (UDP_IP, UDP_PORT))

    if cv2.waitKey(1) & 0xFF == 27:
      break

finally:
  cap.release()
  udp_sock.close()
  IvyStop()
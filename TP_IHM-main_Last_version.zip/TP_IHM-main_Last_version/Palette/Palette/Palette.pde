import java.awt.Point;
import fr.dgac.ivy.*;

ArrayList<Forme> formes;
ArrayList<String> typesFormes;     
ArrayList<String> couleursFormes;  

final int MODE_INITIAL = 0;
final int MODE_AFFICHER = 1;
final int MODE_DEPLACER_SEL = 2;
final int MODE_DEPLACER_DEST = 3;
final int MODE_SUPPRIMER = 4;
final int MODE_CHANGER_COULEUR = 5;

int mode_palette = MODE_INITIAL;
int indice_forme = -1;         
int indice_forme_glissee = -1; 
String couleur_en_attente = "";

Ivy bus;

void setup() {
  size(800, 600);
  surface.setResizable(true);
  surface.setTitle("Palette multimodale");
  
  formes = new ArrayList<Forme>();
  typesFormes = new ArrayList<String>();
  couleursFormes = new ArrayList<String>();
  
  noStroke();
  
  try {
    bus = new Ivy("Palette", "Palette prête", null);
    bus.start("127.255.255.255:2010");

    // 1. CRÉER
    bus.bindMsg("^Palette CreerObjet type=(.*) x=(.*) y=(.*) couleur=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        String typeForme = args[0];
        int cx = int(args[1]);
        int cy = int(args[2]);
        String couleurForme = args[3];
        
        Point p = new Point(cx, cy);
        Forme nouvelleForme = null;
        
        if (typeForme.equals("RECTANGLE")) nouvelleForme = new Rectangle(p);
        else if (typeForme.equals("CIRCLE")) nouvelleForme = new Cercle(p);
        else if (typeForme.equals("TRIANGLE")) nouvelleForme = new Triangle(p);
        else if (typeForme.equals("DIAMOND")) nouvelleForme = new Losange(p);
        else if (typeForme.equals("SQUARE")) nouvelleForme = new Rectangle(p);
        
        if (nouvelleForme != null) {
          applyColorToForme(nouvelleForme, couleurForme);
          formes.add(nouvelleForme);
          typesFormes.add(typeForme);
          couleursFormes.add(couleurForme);
          mode_palette = MODE_AFFICHER;
        }
      }
    });
    
    // 2. MODES COMMANDÉS PAR LA FUSION
    bus.bindMsg("^Palette ModeDeplacement", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) { mode_palette = MODE_DEPLACER_SEL; }
    });
    
    bus.bindMsg("^Palette ModeSuppression", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) { mode_palette = MODE_SUPPRIMER; }
    });
    
    bus.bindMsg("^Palette ModeCouleur couleur=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) { 
        couleur_en_attente = args[0];
        mode_palette = MODE_CHANGER_COULEUR; 
      }
    });
    
    bus.bindMsg("^Palette AnnulerAction", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        mode_palette = MODE_AFFICHER;
        indice_forme = -1;
      }
    });

  } catch (IvyException ie) {}
}

void applyColorToForme(Forme f, String c) {
  if (c.equals("RED")) f.setColor(color(244, 67, 54));
  else if (c.equals("GREEN")) f.setColor(color(76, 175, 80));
  else if (c.equals("BLUE")) f.setColor(color(33, 150, 243));
  else if (c.equals("YELLOW")) f.setColor(color(255, 235, 59));
  else if (c.equals("ORANGE")) f.setColor(color(255, 152, 0));
  else if (c.equals("PURPLE")) f.setColor(color(156, 39, 176));
  else if (c.equals("DARK")) f.setColor(color(33, 33, 33));
  else f.setColor(color(150, 150, 150));
}

void draw() {
  background(255);
  
  for (int i = 0; i < formes.size(); i++) {
    (formes.get(i)).update();
  }
  
  // Bandeau d'instruction en haut de la Palette
  if (mode_palette == MODE_DEPLACER_SEL) {
    dessinerBandeau("MODE DÉPLACEMENT : Cliquez sur la forme à attraper", color(255, 152, 0));
  } else if (mode_palette == MODE_DEPLACER_DEST) {
    dessinerBandeau("DÉPLACEMENT : Cliquez au nouvel emplacement", color(76, 175, 80));
  } else if (mode_palette == MODE_SUPPRIMER) {
    dessinerBandeau("MODE SUPPRESSION : Cliquez sur la forme à supprimer", color(244, 67, 54));
  } else if (mode_palette == MODE_CHANGER_COULEUR) {
    dessinerBandeau("MODE PEINTURE : Cliquez sur la forme à colorier en " + couleur_en_attente, color(33, 150, 243));
  }
}

void dessinerBandeau(String texte, color c) {
  fill(c);
  rect(0, 0, width, 40);
  fill(255);
  textSize(16);
  textAlign(CENTER, CENTER);
  text(texte, width/2, 20);
  textAlign(LEFT, BASELINE);
}

void mousePressed() { 
  Point p = new Point(mouseX, mouseY);
  
  // A. Mode Déplacement (Clic 1 : Sélection)
  if (mode_palette == MODE_DEPLACER_SEL) {
    for (int i = formes.size() - 1; i >= 0; i--) { 
      if ((formes.get(i)).isClicked(p)) {
        indice_forme = i;
        mode_palette = MODE_DEPLACER_DEST;
        try { bus.sendMsg("Palette FormeSelectionnee type=" + typesFormes.get(i) + " couleur=" + couleursFormes.get(i)); } catch (Exception e) {}
        return; 
      }
    }
  }
  // B. Mode Déplacement (Clic 2 : Destination)
  else if (mode_palette == MODE_DEPLACER_DEST) {
    if (indice_forme != -1) {
      (formes.get(indice_forme)).setLocation(p);
      indice_forme = -1; 
    }
    mode_palette = MODE_AFFICHER; 
    try { bus.sendMsg("Palette ActionTerminee"); } catch (Exception e) {}
    return;
  }
  // C. Mode Suppression
  else if (mode_palette == MODE_SUPPRIMER) {
    for (int i = formes.size() - 1; i >= 0; i--) { 
      if ((formes.get(i)).isClicked(p)) {
        formes.remove(i);
        typesFormes.remove(i);
        couleursFormes.remove(i);
        mode_palette = MODE_AFFICHER;
        try { bus.sendMsg("Palette ActionTerminee"); } catch (Exception e) {}
        return;
      }
    }
  }
  // D. Mode Changement de couleur
  else if (mode_palette == MODE_CHANGER_COULEUR) {
    for (int i = formes.size() - 1; i >= 0; i--) { 
      if ((formes.get(i)).isClicked(p)) {
        applyColorToForme(formes.get(i), couleur_en_attente);
        couleursFormes.set(i, couleur_en_attente);
        mode_palette = MODE_AFFICHER;
        try { bus.sendMsg("Palette ActionTerminee"); } catch (Exception e) {}
        return;
      }
    }
  }
  
  // E. Sinon : envoi du clic au moteur de fusion pour les créations + support du drag & drop manuel
  try { if (bus != null) bus.sendMsg("Palette MouseClicked x=" + mouseX + " y=" + mouseY); } catch (Exception e) {}
  
  indice_forme_glissee = -1;
  for (int i = formes.size() - 1; i >= 0; i--) { 
    if ((formes.get(i)).isClicked(p)) {
      indice_forme_glissee = i; 
      break;
    }
  }
}

void mouseDragged() {
  if ((mode_palette == MODE_AFFICHER || mode_palette == MODE_INITIAL) && indice_forme_glissee != -1) {
    (formes.get(indice_forme_glissee)).setLocation(new Point(mouseX, mouseY));
  }
}

void mouseReleased() {
  indice_forme_glissee = -1;
}

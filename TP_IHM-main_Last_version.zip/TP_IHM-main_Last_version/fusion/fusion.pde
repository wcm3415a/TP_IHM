import fr.dgac.ivy.*;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.io.ByteArrayInputStream;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

// =========================================================
// 1. STRUCTURE DE DONNÉES ET MACHINE À ÉTATS
// =========================================================
class CommandeMultimodale {
  String action = "none";     
  String forme = "none";      
  String couleur = "none";    
  boolean positionRequise = false;
  int x = -1, y = -1;         
  
  long tempsClic = 0; 
  final int DUREE_VALIDITE_CLIC = 5000; // 5 secondes
  
  int etatCourant = 0;
  final int ETAT_INIT = 0;
  final int ETAT_ATTENTE_INFO = 1;               
  final int ETAT_ATTENTE_CLIC = 2;               
  final int ETAT_ATTENTE_SELECTION_MOVE = 3;     
  final int ETAT_ATTENTE_DESTINATION_MOVE = 4;   
  final int ETAT_ATTENTE_DELETE = 5;             
  final int ETAT_ATTENTE_COLOR = 6;              
  
  void reinitialiser() {
    action = "none";
    forme = "none";
    couleur = "none";
    positionRequise = false;
    x = -1; y = -1;
    tempsClic = 0;
    etatCourant = ETAT_INIT;
  }
  
  void verifierTimeoutClic() {
    if (x != -1 && millis() - tempsClic > DUREE_VALIDITE_CLIC) {
      x = -1; 
      y = -1;
      println("--- TIMEOUT : Clic expiré (> 5s) ---");
    }
  }
  
  void mettreAJourEtat() {
    // 1. CAS CRÉATION
    if (action.equals("CREATE")) {
      if (forme.equals("none")) {
        etatCourant = ETAT_ATTENTE_INFO;
      } else {
        if (positionRequise) {
          if (x != -1 && y != -1) {
            envoyerCreation(x, y);
          } else {
            etatCourant = ETAT_ATTENTE_CLIC;
          }
        } else {
          int posX = (x != -1) ? x : int(random(100, 700));
          int posY = (y != -1) ? y : int(random(100, 500));
          envoyerCreation(posX, posY);
        }
      }
    }
    // 2. CAS FORME SEULE (Geste souris ou Caméra reçu en premier)
    else if (action.equals("none") && !forme.equals("none")) {
      etatCourant = ETAT_ATTENTE_INFO;
    }
    // 3. CAS DÉPLACEMENT
    else if (action.equals("MOVE")) {
      if (etatCourant != ETAT_ATTENTE_SELECTION_MOVE && etatCourant != ETAT_ATTENTE_DESTINATION_MOVE) {
        etatCourant = ETAT_ATTENTE_SELECTION_MOVE;
        try { bus.sendMsg("Palette ModeDeplacement"); } catch (IvyException e) {}
      }
    }
    // 4. CAS SUPPRESSION
    else if (action.equals("DELETE")) {
      if (etatCourant != ETAT_ATTENTE_DELETE) {
        etatCourant = ETAT_ATTENTE_DELETE;
        try { bus.sendMsg("Palette ModeSuppression"); } catch (IvyException e) {}
      }
    }
    // 5. CAS MODIFIER COULEUR
    else if (action.equals("CHANGE_COLOR")) {
      if (!couleur.equals("none")) {
        if (etatCourant != ETAT_ATTENTE_COLOR) {
          etatCourant = ETAT_ATTENTE_COLOR;
          try { bus.sendMsg("Palette ModeCouleur couleur=" + couleur); } catch (IvyException e) {}
        }
      } else {
        etatCourant = ETAT_ATTENTE_INFO;
      }
    }
  }

  void envoyerCreation(int posX, int posY) {
    try {
      String c = couleur.equals("none") ? "GRAY" : couleur;
      String ordre = "Palette CreerObjet type=" + forme + " x=" + posX + " y=" + posY + " couleur=" + c;
      bus.sendMsg(ordre);
      println(">>> ORDRE ENVOYÉ : " + ordre);
    } catch (IvyException e) {
      println("Erreur Ivy : " + e.getMessage());
    }
    reinitialiser();
  }
  
  // =========================================================
  // INTERFACE DU DASHBOARD (AVEC RETOUR CAMÉRA EN DIRECT)
  // =========================================================
  void dessinerInterface() {
    color cardBg = color(45, 52, 64);
    color textLight = color(240);
    color textMuted = color(165);
    color blueAccent = color(66, 165, 245);
    color greenAccent = color(76, 175, 80);

    // --- 1. HAUT-GAUCHE : COMMANDES VOCALES ---
    fill(cardBg); noStroke(); rect(20, 70, 345, 240, 14);
    dessinerIconeMicro(42, 95, blueAccent);
    fill(blueAccent); textSize(16); textAlign(LEFT);
    text("1. COMMANDES VOCALES", 60, 101);
    
    fill(textLight); textSize(13);
    text("• Créer : \"Créer [forme] [couleur] (ici)\"", 35, 135);
    text("• Déplacer : \"Déplacer\" + clic forme", 35, 162);
    text("• Supprimer : \"Supprimer\" + clic forme", 35, 189);
    text("• Couleur : \"Modifier en [couleur]\"", 35, 216);
    fill(textMuted); textSize(12);
    text("Couleurs : Rouge, Vert, Bleu, Jaune, Noir...", 35, 250);
    text("Astuce : Faites un geste puis dites \"Créer ici\" !", 35, 278);
    
    // --- 2. HAUT-MILIEU : GESTES SOURIS ($1) ---
    fill(cardBg); rect(385, 70, 345, 240, 14);
    dessinerIconeCrayon(407, 95, blueAccent);
    fill(blueAccent); textSize(16);
    text("2. GESTES SOURIS ($1)", 425, 101);
    
    fill(textLight); textSize(13);
    text("Tracez une forme dans OneDollar :", 400, 135);
    
    noFill(); stroke(textLight); strokeWeight(2);
    rect(405, 160, 36, 36);             
    ellipse(498, 178, 38, 38);          
    triangle(578, 160, 558, 196, 598, 196); 
    quad(665, 158, 645, 178, 665, 198, 685, 178); 
    noStroke();
    
    fill(textMuted); textSize(12); textAlign(CENTER);
    text("Carré", 423, 218); 
    text("Cercle", 498, 218); 
    text("Triangle", 578, 218); 
    text("Losange", 665, 218);
    textAlign(LEFT);
    fill(textLight); textSize(13);
    text("La forme tracée est stockée dans", 400, 252);
    text("les Slots en attente de \"Créer\".", 400, 274);

    // --- 3. HAUT-DROITE : CAMÉRA TEMPS RÉEL (DOIGTS) ---
    fill(cardBg); rect(750, 70, 350, 240, 14);
    dessinerIconeCamera(772, 95, blueAccent);
    fill(blueAccent); textSize(16);
    text("3. CAMÉRA (GESTES MAINS)", 795, 101);
    
    // Affichage du flux vidéo reçu en UDP
    if (camFrame != null && millis() - lastCamTime < 3000) {
      image(camFrame, 765, 112, 320, 172);
    } else {
      fill(30, 35, 45);
      rect(765, 112, 320, 172, 8);
      fill(130); textSize(13); textAlign(CENTER);
      text("Caméra non connectée", 925, 190);
      textSize(11); fill(100);
      text("(Lancez camera_gesture.py)", 925, 210);
      textAlign(LEFT);
    }
    fill(textMuted); textSize(11); textAlign(CENTER);
    text("1:Carré  |  2:Cercle  |  3:Triangle  |  4:Losange", 925, 300);
    textAlign(LEFT);

    // --- 4. BAS-GAUCHE : MÉMOIRE (SLOTS) ---
    fill(cardBg); rect(20, 330, 520, 240, 14);
    dessinerIconeMemoire(42, 355, greenAccent);
    fill(greenAccent); textSize(17);
    text("MÉMOIRE DE FUSION (SLOTS)", 62, 362);
    
    textSize(14);
    dessinerSlot("Action", traduireAction(action), !action.equals("none"), 40, 405);
    dessinerSlot("Forme", traduireForme(forme), !forme.equals("none"), 40, 445);
    dessinerSlot("Couleur", couleur, !couleur.equals("none"), 40, 485);
    
    String textePos = "Non définie";
    boolean posActive = false;
    if (x != -1) {
      int restant = max(0, (DUREE_VALIDITE_CLIC - (millis() - (int)tempsClic)) / 1000 + 1);
      textePos = x + ", " + y + " (" + restant + "s)";
      posActive = true;
    } else if (positionRequise) {
      textePos = "Attente clic palette...";
      posActive = true;
    }
    dessinerSlot("Position", textePos, posActive, 40, 525);

    // --- 5. BAS-DROITE : FEEDBACK & TIMER ---
    fill(cardBg); rect(560, 330, 540, 240, 14);
    dessinerFeedbackActif(830, 365);
  }

  void dessinerFeedbackActif(int centerX, int topY) {
    if (etatCourant == ETAT_ATTENTE_INFO && !forme.equals("none") && action.equals("none")) {
      afficherTexteFeedback("FORME EN ATTENTE", "Dites \"Créer\" (ou \"Créer en rouge ici\")", "pour placer votre " + traduireForme(forme), color(66, 165, 245), centerX);
      dessinerFormeVibrante(centerX, 495);
    }
    else if (etatCourant == ETAT_ATTENTE_INFO && forme.equals("none") && action.equals("CREATE")) {
      afficherTexteFeedback("QUELLE FORME ?", "Montrez 1 à 4 doigts à la caméra, tracez sur $1", "ou dites son nom (carré, cercle...)", color(66, 165, 245), centerX);
    }
    else if (etatCourant == ETAT_ATTENTE_INFO && action.equals("CHANGE_COLOR")) {
      afficherTexteFeedback("QUELLE COULEUR ?", "Dites une couleur (ex: \"Bleu\", \"Rouge\")", "pour passer en mode peinture", color(66, 165, 245), centerX);
    }
    else if (etatCourant == ETAT_ATTENTE_CLIC && !forme.equals("none")) {
      afficherTexteFeedback("CLIQUEZ SUR LA PALETTE", "Cliquez à l'endroit voulu pour poser", "votre " + traduireForme(forme), color(255, 193, 7), centerX);
      dessinerFormeVibrante(centerX, 495);
    }
    else if (etatCourant == ETAT_ATTENTE_SELECTION_MOVE) {
      afficherTexteFeedback("MODE DÉPLACEMENT (1/2)", "Cliquez sur une forme dans la Palette", "pour la sélectionner", color(255, 152, 0), centerX);
    }
    else if (etatCourant == ETAT_ATTENTE_DESTINATION_MOVE) {
      afficherTexteFeedback("MODE DÉPLACEMENT (2/2)", "Cliquez sur la nouvelle position", "dans la Palette pour la déposer", color(76, 175, 80), centerX);
      dessinerFormeVibrante(centerX, 495);
    }
    else if (etatCourant == ETAT_ATTENTE_DELETE) {
      afficherTexteFeedback("MODE SUPPRESSION", "Cliquez sur une forme dans la Palette", "pour la détruire immédiatement", color(244, 67, 54), centerX);
    }
    else if (etatCourant == ETAT_ATTENTE_COLOR) {
      afficherTexteFeedback("MODE PEINTURE (" + couleur + ")", "Cliquez sur une forme dans la Palette", "pour lui appliquer cette couleur", color(33, 150, 243), centerX);
    }
    else {
      fill(160); textSize(16); textAlign(CENTER);
      text("Système prêt - En écoute...", centerX, 435);
      textSize(13); fill(120);
      text("Voix (SRA5)  •  Geste ($1)  •  Caméra (Doigts)  •  Souris (Palette)", centerX, 460);
      textAlign(LEFT);
    }

    // --- JAUGE TEMPORELLE DU CLIC MÉMORISÉ ---
    if (x != -1) {
      int ecoule = millis() - (int)tempsClic;
      int restant = DUREE_VALIDITE_CLIC - ecoule;
      if (restant > 0) {
        float ratio = constrain((float)restant / DUREE_VALIDITE_CLIC, 0, 1);
        
        fill(30, 35, 45);
        rect(centerX - 180, 535, 360, 12, 6);
        
        if (ratio > 0.5) fill(76, 175, 80);
        else if (ratio > 0.25) fill(255, 193, 7);
        else fill(244, 67, 54);
        
        rect(centerX - 180, 535, 360 * ratio, 12, 6);
        
        fill(220); textSize(12); textAlign(CENTER);
        text("Pointage (" + x + ", " + y + ") actif pendant " + nf(restant / 1000.0, 1, 1) + "s", centerX, 562);
        textAlign(LEFT);
      }
    }
  }

  // --- ICÔNES VECTORIELLES ---
  void dessinerIconeMicro(int cx, int cy, color c) {
    noStroke(); fill(c);
    rect(cx - 4, cy - 10, 8, 13, 4);
    noFill(); stroke(c); strokeWeight(2);
    arc(cx, cy - 2, 14, 14, 0, PI);
    line(cx, cy + 5, cx, cy + 9);
    line(cx - 5, cy + 9, cx + 5, cy + 9);
    noStroke();
  }

  void dessinerIconeCrayon(int cx, int cy, color c) {
    pushMatrix(); translate(cx, cy); rotate(radians(45));
    noStroke(); fill(c);
    rect(-3, -10, 6, 14);
    triangle(-3, 4, 3, 4, 0, 9);
    popMatrix();
  }

  void dessinerIconeCamera(int cx, int cy, color c) {
    noStroke(); fill(c);
    rect(cx - 9, cy - 6, 14, 12, 3);
    triangle(cx + 5, cy, cx + 11, cy - 5, cx + 11, cy + 5);
  }

  void dessinerIconeMemoire(int cx, int cy, color c) {
    noFill(); stroke(c); strokeWeight(2);
    rect(cx - 7, cy - 7, 14, 14, 3);
    fill(c); noStroke();
    rect(cx - 3, cy - 3, 6, 6);
  }

  void afficherTexteFeedback(String titre, String l1, String l2, color c, int centerX) {
    fill(c, 40);
    rect(centerX - 220, 345, 440, 36, 8);
    fill(c); textSize(16); textAlign(CENTER);
    text(titre, centerX, 369);
    fill(240); textSize(14);
    text(l1, centerX, 405);
    fill(180); textSize(13);
    text(l2, centerX, 428);
    textAlign(LEFT);
  }

  void dessinerSlot(String nom, String valeur, boolean actif, int px, int py) {
    fill(190); textAlign(LEFT); text(nom + " :", px, py);
    if (actif) {
      fill(66, 165, 245);
      rect(px + 100, py - 16, textWidth(valeur) + 28, 24, 12);
      fill(255);
      text(valeur, px + 114, py + 1);
    } else {
      fill(60, 68, 82);
      rect(px + 100, py - 16, 80, 24, 12);
      fill(130);
      text("Vide", px + 124, py + 1);
    }
  }
  
  String traduireForme(String f) {
    if (f.equals("SQUARE")) return "CARRÉ"; 
    if (f.equals("RECTANGLE")) return "RECTANGLE";
    if (f.equals("CIRCLE")) return "CERCLE"; 
    if (f.equals("TRIANGLE")) return "TRIANGLE";
    if (f.equals("DIAMOND")) return "LOSANGE"; 
    return f;
  }

  String traduireAction(String a) {
    if (a.equals("CREATE")) return "CRÉER";
    if (a.equals("MOVE")) return "DÉPLACER";
    if (a.equals("DELETE")) return "SUPPRIMER";
    if (a.equals("CHANGE_COLOR")) return "COULEUR";
    return a;
  }

  void dessinerFormeVibrante(int cx, int cy) {
    pushMatrix(); translate(cx + random(-1.5, 1.5), cy + random(-1.5, 1.5)); 
    if (couleur.equals("RED")) fill(244, 67, 54); 
    else if (couleur.equals("GREEN")) fill(76, 175, 80);
    else if (couleur.equals("BLUE")) fill(33, 150, 243); 
    else if (couleur.equals("YELLOW")) fill(255, 235, 59);
    else if (couleur.equals("ORANGE")) fill(255, 152, 0); 
    else if (couleur.equals("PURPLE")) fill(156, 39, 176);
    else if (couleur.equals("DARK")) fill(33, 33, 33); 
    else fill(158, 158, 158); 
    
    stroke(255, 120); strokeWeight(2); rectMode(CENTER);
    if (forme.equals("RECTANGLE")) rect(0, 0, 70, 44, 4); 
    else if (forme.equals("SQUARE")) rect(0, 0, 52, 52, 4);
    else if (forme.equals("CIRCLE")) ellipse(0, 0, 56, 56); 
    else if (forme.equals("TRIANGLE")) triangle(-28, 24, 0, -24, 28, 24);
    else if (forme.equals("DIAMOND")) quad(0, -30, 24, 0, 0, 30, -24, 0);
    noStroke(); rectMode(CORNER); popMatrix();
  }
}

// =========================================================
// 2. PROGRAMME PRINCIPAL ET RÉCEPTION VIDÉO UDP
// =========================================================
Ivy bus;
CommandeMultimodale cmd;

volatile PImage camFrame = null;
volatile long lastCamTime = 0;
DatagramSocket videoSocket;

void setup() {
  size(1120, 600); 
  surface.setTitle("Tableau de Bord - Moteur de Fusion Multimodale");
  cmd = new CommandeMultimodale();
  
  // Lancement du récepteur vidéo UDP en arrière-plan (Port 5005)
  lancerServeurVideoUDP();
  
  try {
    bus = new Ivy("MoteurFusion", "Moteur prêt", null);
    bus.start("127.255.255.255:2010"); 
    
    // --- A. ÉCOUTE DE LA VOIX ---
    bus.bindMsg("^sra5 Text=(.*) Confidence=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        String phrase = args[0].toLowerCase().trim();
        println("\n--- VOIX REÇUE : " + phrase + " ---");
        
        if (phrase.contains("créer") || phrase.contains("creer") || phrase.contains("dessiner") || phrase.contains("tracer") || phrase.contains("ajout")) {
          cmd.action = "CREATE";
        } else if (phrase.contains("supprimer") || phrase.contains("effacer") || phrase.contains("détruire")) {
          cmd.action = "DELETE";
        } else if (phrase.contains("déplacer") || phrase.contains("deplacer") || phrase.contains("bouger")) {
          cmd.action = "MOVE";
        } else if (phrase.contains("modifier") || phrase.contains("changer") || phrase.contains("couleur") || phrase.contains("peindre")) {
          cmd.action = "CHANGE_COLOR";
        }
        
        if (phrase.contains("rectangle")) cmd.forme = "RECTANGLE";
        else if (phrase.contains("cercle") || phrase.contains("rond")) cmd.forme = "CIRCLE";
        else if (phrase.contains("triangle")) cmd.forme = "TRIANGLE";
        else if (phrase.contains("losange")) cmd.forme = "DIAMOND";
        else if (phrase.contains("carré") || phrase.contains("carre")) cmd.forme = "SQUARE";
        
        if (phrase.contains("rouge")) cmd.couleur = "RED";
        else if (phrase.contains("vert")) cmd.couleur = "GREEN";
        else if (phrase.contains("bleu")) cmd.couleur = "BLUE";
        else if (phrase.contains("jaune")) cmd.couleur = "YELLOW";
        else if (phrase.contains("noir")) cmd.couleur = "DARK";
        else if (phrase.contains("orange")) cmd.couleur = "ORANGE";
        else if (phrase.contains("violet") || phrase.contains("mauve")) cmd.couleur = "PURPLE";
        
        if (phrase.contains("ici") || phrase.contains("là") || phrase.contains("la") || phrase.contains("endroit")) {
          cmd.positionRequise = true;
        }
        
        cmd.mettreAJourEtat(); 
      }
    });

    // --- B. ÉCOUTE DES GESTES ($1 ET CAMÉRA PYTHON) ---
    bus.bindMsg("^OneDollarIvy Template=([^ ]+) Confidence=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        String geste = args[0];
        println("\n--- GESTE REÇU : " + geste + " ---");
        
        if (geste.equalsIgnoreCase("rectangle") || geste.equalsIgnoreCase("rect")) cmd.forme = "RECTANGLE";
        else if (geste.equalsIgnoreCase("circle") || geste.equalsIgnoreCase("cercle")) cmd.forme = "CIRCLE";
        else if (geste.equalsIgnoreCase("triangle")) cmd.forme = "TRIANGLE";
        else if (geste.equalsIgnoreCase("diamond") || geste.equalsIgnoreCase("losange")) cmd.forme = "DIAMOND";
        else if (geste.equalsIgnoreCase("square") || geste.equalsIgnoreCase("carre")) cmd.forme = "SQUARE";
        
        cmd.mettreAJourEtat(); 
      }
    });

    // --- C. RETOURS D'ACTIONS DE LA PALETTE ---
    bus.bindMsg("^Palette FormeSelectionnee type=(.*) couleur=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        cmd.forme = args[0];
        cmd.couleur = args[1];
        cmd.etatCourant = cmd.ETAT_ATTENTE_DESTINATION_MOVE;
      }
    });
    
    bus.bindMsg("^Palette ActionTerminee", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        cmd.reinitialiser();
      }
    });

    // --- D. ÉCOUTE DES CLICS SOURIS ---
    bus.bindMsg("^Palette MouseClicked x=(.*) y=(.*)", new IvyMessageListener() {
      public void receive(IvyClient client, String[] args) {
        if (cmd.etatCourant == cmd.ETAT_INIT || cmd.etatCourant == cmd.ETAT_ATTENTE_INFO || cmd.etatCourant == cmd.ETAT_ATTENTE_CLIC) {
          cmd.x = int(args[0]);
          cmd.y = int(args[1]);
          cmd.tempsClic = millis();
          println("\n--- CLIC REÇU : X=" + cmd.x + " Y=" + cmd.y + " (Valide 5s) ---");
          cmd.mettreAJourEtat(); 
        }
      }
    });

  } catch (IvyException ie) {
    println("Erreur Ivy : " + ie.getMessage());
  }
}

// Thread dédié à la réception des images JPEG envoyées par camera_gesture.py
void lancerServeurVideoUDP() {
  Thread t = new Thread(new Runnable() {
    public void run() {
      try {
        videoSocket = new DatagramSocket(5005);
        byte[] buffer = new byte[65507];
        while (true) {
          DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
          videoSocket.receive(packet);
          ByteArrayInputStream bais = new ByteArrayInputStream(packet.getData(), 0, packet.getLength());
          BufferedImage bimg = ImageIO.read(bais);
          if (bimg != null) {
            PImage img = new PImage(bimg.getWidth(), bimg.getHeight(), RGB);
            bimg.getRGB(0, 0, img.width, img.height, img.pixels, 0, img.width);
            img.updatePixels();
            camFrame = img;
            lastCamTime = millis();
          }
        }
      } catch (Exception e) {
        println("Info Serveur Vidéo UDP : " + e.getMessage());
      }
    }
  });
  t.setDaemon(true);
  t.start();
}

void draw() {
  background(28, 32, 42); 
  
  cmd.verifierTimeoutClic();
  
  fill(255); textSize(22); textAlign(CENTER);
  text("MOTEUR DE FUSION MULTIMODALE", width/2, 34);
  textSize(13); fill(165);
  text("Combinez la Voix, le Geste ($1), la Caméra (Doigts) et le Pointage Souris", width/2, 54);
  textAlign(LEFT);
  
  cmd.dessinerInterface();
  
  fill(120); textSize(12); textAlign(CENTER);
  text("Appuyez sur la touche 'R' pour annuler l'action en cours et vider la mémoire", width/2, 590);
  textAlign(LEFT);
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    cmd.reinitialiser();
    try { bus.sendMsg("Palette AnnulerAction"); } catch (Exception e) {}
    println("--- AUTOMATE RÉINITIALISÉ ---");
  }
}
